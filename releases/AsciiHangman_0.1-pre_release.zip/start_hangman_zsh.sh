#!/bin/zsh
echo "Starting main.py..."
python3 src/main.py
