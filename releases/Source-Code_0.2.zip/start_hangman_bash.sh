#!/bin/bash
echo "Starting hangman.py..."
<<<<<<< HEAD
.venv/bin/python3 src/main.py
=======
.venv/bin/python3 hangman.py
>>>>>>> 9ac863f7069031eca6aeea19d51a0769622bf4e8
