from src.main import *


def init():
    welcome_script()
